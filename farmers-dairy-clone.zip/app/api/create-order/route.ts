import { type NextRequest, NextResponse } from "next/server"

// Simple in-memory storage for demo purposes
// In production, you would use a proper database
const orders: any[] = []

export async function POST(request: NextRequest) {
  try {
    const order = await request.json()

    // Add timestamp and ID if not present
    const orderWithMetadata = {
      ...order,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
    }

    orders.push(orderWithMetadata)

    return NextResponse.json({ success: true, orderId: orderWithMetadata.id })
  } catch (error) {
    console.error("Error creating order:", error)
    return NextResponse.json({ success: false, error: "Failed to create order" }, { status: 500 })
  }
}
