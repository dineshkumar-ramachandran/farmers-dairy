import { NextResponse } from "next/server"

// Simple in-memory storage for demo purposes
// In production, you would use a proper database
const orders: any[] = []

export async function GET() {
  try {
    return NextResponse.json({ orders })
  } catch (error) {
    console.error("Error fetching orders:", error)
    return NextResponse.json({ orders: [] })
  }
}
